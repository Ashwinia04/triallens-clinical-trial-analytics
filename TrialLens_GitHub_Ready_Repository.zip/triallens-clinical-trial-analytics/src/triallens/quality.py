"""Rule-based data-quality checks for the simulated trial exports."""
from __future__ import annotations
import pandas as pd

ISSUE_COLUMNS = ["issue_id", "severity", "domain", "record_key", "rule_id", "description"]


def _issue(rows: list[dict], severity: str, domain: str, key: str, rule: str, description: str) -> None:
    rows.append({
        "issue_id": f"ISSUE-{len(rows) + 1:04d}",
        "severity": severity,
        "domain": domain,
        "record_key": str(key),
        "rule_id": rule,
        "description": description,
    })


def run_quality_checks(data: dict[str, pd.DataFrame]) -> pd.DataFrame:
    issues: list[dict] = []
    p = data["participants"].copy()
    v = data["visits"].copy()
    l = data["labs"].copy()
    ae = data["adverse_events"].copy()
    q = data["queries"].copy()

    # Participant-level checks.
    dup_p = p[p.duplicated("participant_id", keep=False)]
    for pid in sorted(dup_p["participant_id"].astype(str).unique()):
        _issue(issues, "High", "DM", pid, "DM-001", "Duplicate participant_id found in the participant export.")
    required_p = ["participant_id", "site_id", "treatment_arm", "age", "consent_date", "randomization_date"]
    # Treat nulls and whitespace-only strings as missing. The CSV loader keeps
    # empty strings so that source exports remain faithful to their raw values.
    required_missing = p[required_p].apply(
        lambda column: column.isna() | column.astype(str).str.strip().eq("")
    ).any(axis=1)
    for _, row in p[required_missing].iterrows():
        _issue(issues, "High", "DM", row.get("participant_id", "unknown"), "DM-002", "One or more required participant fields are missing.")
    age = pd.to_numeric(p["age"], errors="coerce")
    for idx in p.index[age.lt(18) | age.gt(80) | age.isna()]:
        _issue(issues, "High", "DM", p.loc[idx, "participant_id"], "DM-003", "Age is missing or outside the protocol eligibility range of 18–80 years.")
    consent = pd.to_datetime(p["consent_date"], errors="coerce")
    randomization = pd.to_datetime(p["randomization_date"], errors="coerce")
    for idx in p.index[consent.isna() | randomization.isna() | randomization.lt(consent)]:
        _issue(issues, "Critical", "DM", p.loc[idx, "participant_id"], "DM-004", "Randomization date is missing/invalid or precedes informed-consent date.")

    # Visit-level checks.
    v_key = ["participant_id", "visit_name"]
    dup_v = v[v.duplicated(v_key, keep=False)]
    for key in sorted((str(a), str(b)) for a, b in dup_v[v_key].drop_duplicates().itertuples(index=False, name=None)):
        _issue(issues, "High", "SV", "|".join(key), "SV-001", "More than one record exists for the same participant and scheduled visit.")
    actual = pd.to_datetime(v["actual_date"], errors="coerce")
    planned = pd.to_datetime(v["planned_date"], errors="coerce")
    missing_actual = v["visit_status"].eq("Completed") & actual.isna()
    for idx in v.index[missing_actual]:
        _issue(issues, "High", "SV", v.loc[idx, "visit_id"], "SV-002", "Visit is marked Completed but actual_date is missing or invalid.")
    window = pd.to_numeric(v["window_days"], errors="coerce").fillna(0)
    outside = v["visit_status"].eq("Completed") & actual.notna() & planned.notna() & ((actual - planned).dt.days.abs() > window)
    for idx in v.index[outside]:
        _issue(issues, "Medium", "SV", v.loc[idx, "visit_id"], "SV-003", "Completed visit falls outside the permitted visit window.")

    # Laboratory checks.
    lab_key = ["participant_id", "visit_name", "test_name"]
    dup_l = l[l.duplicated(lab_key, keep=False)]
    for key in sorted(tuple(map(str, values)) for values in dup_l[lab_key].drop_duplicates().itertuples(index=False, name=None)):
        _issue(issues, "High", "LB", "|".join(key), "LB-001", "Duplicate participant/visit/test laboratory result found.")
    expected_units = {"hsCRP": "mg/L", "ALT": "U/L"}
    for idx, row in l.iterrows():
        expected = expected_units.get(row["test_name"])
        if expected and row["unit"] != expected:
            _issue(issues, "High", "LB", row["lab_id"], "LB-002", f"Unexpected unit for {row['test_name']}: expected {expected}; received {row['unit']}.")

    # Adverse-event and query checks.
    onset = pd.to_datetime(ae["onset_date"], errors="coerce")
    end = pd.to_datetime(ae["end_date"], errors="coerce")
    for idx in ae.index[end.notna() & onset.notna() & end.lt(onset)]:
        _issue(issues, "Critical", "AE", ae.loc[idx, "ae_id"], "AE-001", "Adverse-event end_date precedes onset_date.")
    closed_missing = q["status"].eq("Closed") & pd.to_datetime(q["closed_date"], errors="coerce").isna()
    for idx in q.index[closed_missing]:
        _issue(issues, "Medium", "Queries", q.loc[idx, "query_id"], "QRY-001", "Query is marked Closed but closed_date is missing or invalid.")

    return pd.DataFrame(issues, columns=ISSUE_COLUMNS)
