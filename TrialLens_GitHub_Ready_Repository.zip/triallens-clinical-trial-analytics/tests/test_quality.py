from pathlib import Path
import pandas as pd
from triallens.generate_data import generate_dataset
from triallens.quality import run_quality_checks
from triallens.analysis import analyze_trial


def build_data(tmp_path):
    return generate_dataset(tmp_path)


def test_quality_checks_flag_expected_rule_families(tmp_path):
    data = build_data(tmp_path)
    issues = run_quality_checks(data)
    expected = {"DM-001", "DM-003", "DM-004", "SV-001", "SV-002", "SV-003", "LB-001", "LB-002", "AE-001", "QRY-001"}
    assert expected.issubset(set(issues["rule_id"]))


def test_analysis_excludes_invalid_participant_rows(tmp_path):
    data = build_data(tmp_path)
    result = analyze_trial(data)
    assert result["metrics"]["participants_in_analysis"] < result["metrics"]["participants_in_raw_export"]
    assert result["metrics"]["participants_in_analysis"] > 100


def test_biomarker_summary_has_both_randomized_groups(tmp_path):
    data = build_data(tmp_path)
    result = analyze_trial(data)
    assert set(result["biomarker_summary"]["treatment_arm"]) == {"TRX-101", "Placebo"}
    assert result["metrics"]["paired_hscrp_participants"] > 80


def test_all_issues_have_traceable_rule_ids(tmp_path):
    data = build_data(tmp_path)
    issues = run_quality_checks(data)
    assert issues["rule_id"].notna().all()
    assert issues["issue_id"].is_unique


def test_required_fields_flag_blank_strings_as_missing(tmp_path):
    data = build_data(tmp_path)
    data["participants"].loc[0, "site_id"] = "   "
    issues = run_quality_checks(data)
    assert "DM-002" in set(issues["rule_id"])
