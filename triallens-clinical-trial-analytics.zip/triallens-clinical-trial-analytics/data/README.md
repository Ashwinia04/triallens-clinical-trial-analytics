# Data documentation

All files in `raw/` are generated locally by `src/triallens/generate_data.py` with a fixed random seed. They are entirely synthetic and contain no real patient information.

| File | Grain | Purpose |
|---|---|---|
| `participants.csv` | One intended row per participant | Site, randomized group, demographics, consent and disposition |
| `visits.csv` | One intended row per participant and scheduled visit | Planned/actual visit dates, visit status and visit window |
| `labs.csv` | One intended row per participant, visit and test | hsCRP and ALT results with units and reference limits |
| `adverse_events.csv` | One row per reported AE | Event term, dates, severity, seriousness, relatedness and outcome |
| `protocol_deviations.csv` | One row per deviation | Deviation category, severity and reportability |
| `queries.csv` | One row per data query | Domain, issue type, status and query dates |

A small number of intentional data-entry anomalies are injected to demonstrate validation (duplicate IDs/records, age and date inconsistencies, an unexpected laboratory unit, and incomplete query closure data). These are documented in the generator and surfaced by the QA pipeline. Do not use these data for clinical, regulatory, or treatment decisions.
