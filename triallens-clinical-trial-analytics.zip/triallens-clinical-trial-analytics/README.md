# TrialLens: Clinical Trial Data Quality & Safety Analytics

**A reproducible Python + SQL portfolio project using a fully synthetic Phase II trial dataset.**

TrialLens demonstrates how a junior clinical data / healthcare analytics candidate can structure a practical review of trial data: profile source exports, run explicit data-quality checks, summarize visit conduct and adverse-event records, review query resolution, and perform a carefully labelled exploratory biomarker comparison.

> **Important:** This is an educational portfolio simulation. TRX-101, the study, participants, sites, records, and results are fictional. No real patient data or real clinical-trial system is used. It is not validated software and must not be used to make clinical, safety, regulatory, or treatment decisions.

## Why this project matters

Clinical data work requires more than producing charts. It depends on traceable checks, consistent data definitions, careful handling of missing and duplicate records, and transparent interpretation. This project brings those elements together in one reproducible workflow.

## What it demonstrates

- **Clinical data review:** participant, visit, laboratory, adverse-event, protocol-deviation and query datasets.
- **Data quality:** 10+ rule-based checks covering duplicate records, required fields, eligibility range, date chronology, visit windows, laboratory units, AE date logic and query closure dates.
- **Clinical operations:** visit completion and within-window rates, protocol deviation summaries and query closure turnaround.
- **Safety data summaries:** AE counts by seriousness and randomized group, affected-participant counts and common event terms.
- **Exploratory analysis:** paired baseline-to-Week-12 hsCRP change by randomized group, with Welch's t-test and Cohen's d, explicitly labelled as synthetic and exploratory.
- **Technical delivery:** Python/pandas, SQLite SQL, a Streamlit dashboard, reproducible data generation and automated tests.

## Project structure

```text
triallens-clinical-trial-analytics/
├── app.py                         # Streamlit dashboard
├── data/
│   ├── README.md                  # Dataset dictionary and caveats
│   └── raw/                       # Synthetic source exports (CSV)
├── outputs/
│   ├── metrics.json               # Key metrics
│   ├── quality_issues.csv         # Traceable validation findings
│   ├── *_summary.csv              # Analysis tables
│   ├── triallens.db               # SQLite database of source tables + QA findings
│   └── plots/                     # Generated figures
├── reports/analysis_summary.md    # Human-readable run summary
├── sql/analysis_queries.sql       # Example SQL review queries
├── src/triallens/
│   ├── generate_data.py           # Deterministic synthetic data generator
│   ├── quality.py                 # Validation rules
│   ├── analysis.py                # Cohort, operations, safety and lab analysis
│   └── pipeline.py                # End-to-end runner
└── tests/test_quality.py          # Automated tests
```

## Run it locally

Python 3.10+ is recommended.

### 1. Create an environment and install dependencies

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Run the pipeline

From the repository root:

```bash
python -m pip install -e .
python -m triallens.pipeline --regenerate
```

The pipeline writes QA findings, analysis tables, plots, a SQLite database and a Markdown summary into `outputs/` and `reports/`.

### 3. Launch the dashboard

```bash
streamlit run app.py
```

### 4. Run tests

```bash
pytest -q
```

## Key outputs

| Output | What it tells you |
|---|---|
| `outputs/quality_issues.csv` | Each finding has an issue ID, severity, domain, record key, rule ID and description |
| `outputs/visit_summary.csv` | Scheduled visit completion and within-window rates |
| `outputs/ae_summary.csv` | AE counts by treatment arm and seriousness |
| `outputs/ae_term_summary.csv` | Most frequently reported synthetic AE terms |
| `outputs/deviation_summary.csv` | Deviations by category and severity |
| `outputs/biomarker_summary.csv` | Paired hsCRP summary by randomized group |
| `outputs/metrics.json` | Compact operational and analysis metrics |
| `outputs/triallens.db` | SQLite copy for additional SQL exploration |

## Data-quality rules

| Rule ID | Domain | Check |
|---|---|---|
| DM-001 | Demographics | Duplicate participant identifier |
| DM-002 | Demographics | Missing required participant fields |
| DM-003 | Demographics | Age outside the simulated 18–80 eligibility range |
| DM-004 | Demographics | Invalid date or randomization before consent |
| SV-001 | Visits | Duplicate participant/visit record |
| SV-002 | Visits | Completed visit without a valid actual date |
| SV-003 | Visits | Completed visit outside its permitted window |
| LB-001 | Labs | Duplicate participant/visit/test result |
| LB-002 | Labs | Unit inconsistent with the expected test unit |
| AE-001 | Safety | AE end date before onset date |
| QRY-001 | Queries | Closed query without a valid close date |

The pipeline flags findings; it does not silently modify the source data. For downstream analysis, only explicit documented handling is applied (for example, deduplicating the intended participant/visit/test grain and excluding invalid chronology or unexpected lab units from the relevant summary).

## Analysis notes and limitations

- The simulated study has two randomized groups and scheduled Baseline, Week 4, Week 8 and Week 12 visits.
- The biomarker endpoint is hsCRP (mg/L), measured at Baseline and Week 12. The comparison is illustrative and does not establish efficacy.
- Missing observations are not imputed. The paired biomarker summary includes only participants with both valid measurements.
- The AE summary is descriptive. It does not assess exposure-adjusted incidence, adjudicate causality, or replace medical review.
- The query summary is a simplified operational measure; production workflows would need formal query lifecycle definitions, audit trails and role-based controls.
- This project does not claim CDISC/SDTM conformance, validated EDC integration, GxP validation, or production clinical-data-management experience.

## Next enhancements

1. Add a formal data dictionary with controlled terminology and field-level metadata.
2. Add cross-domain referential-integrity checks and a configurable rule catalogue.
3. Add a missing-data and protocol-deviation dashboard by site.
4. Add a CDISC SDTM mapping exercise using a separate educational example dataset.
5. Add CI checks and code coverage reporting.

## Suggested CV / LinkedIn project entry

**TrialLens — Clinical Trial Data Quality & Safety Analytics (Python, SQL, pandas, Streamlit)**  
Built a reproducible analytics pipeline on a simulated Phase II trial dataset; implemented 11 traceable validation rules across participant, visit, laboratory, AE and query records, and summarized protocol-window compliance, query closure, safety events and exploratory biomarker trends. Added SQLite queries, a Streamlit dashboard and automated tests.

Use this wording only after you have run the project and can explain each component. Keep the word **simulated** visible so recruiters do not mistake it for real clinical-trial work.

## Repository topics

`clinical-data-management` `clinical-trial-analytics` `data-quality` `pharmacovigilance` `healthcare-analytics` `python` `sql` `streamlit` `synthetic-data`

## License

MIT. See `LICENSE`.
