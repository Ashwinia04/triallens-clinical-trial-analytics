# TrialLens — Interview walkthrough

Use this guide to explain the project clearly. Be precise that it is a learning/portfolio simulation using synthetic data.

## 60–90 second project explanation

“I built TrialLens, a Python and SQL portfolio project to demonstrate how I would approach an initial clinical-trial data review. I generated a fictional Phase II study dataset with participant, visit, laboratory, adverse-event, protocol-deviation and query records. I implemented 11 traceable validation rules, including duplicate checks, eligibility/date chronology, visit-window checks, laboratory-unit checks, AE date logic and query closure checks. The pipeline then summarizes visit compliance, adverse-event patterns, query closure and paired hsCRP changes. I also added SQLite queries, a Streamlit dashboard and automated tests. The dataset is entirely synthetic, so the results are only for demonstrating the workflow—not for clinical decisions.”

## Walk through the architecture

1. `generate_data.py` creates deterministic synthetic CSV exports with a small set of known data-entry anomalies.
2. `quality.py` applies transparent validation rules and creates an issue log with a severity, domain, record key and rule ID.
3. `analysis.py` applies documented inclusion rules and produces operational, safety and exploratory biomarker summaries.
4. `pipeline.py` orchestrates the workflow and writes CSV outputs, JSON metrics, plots, a Markdown report and a SQLite database.
5. `app.py` provides a dashboard to review findings and summaries; `tests/` checks core expected behaviour.

## Questions a recruiter or interviewer may ask

**Why did you choose this project?**  
It connects my healthcare background and Medical Bioinformatics education with my clinical-research training. It demonstrates practical thinking about data accuracy, traceability, safety summaries and analysis rather than only presenting a model score.

**Why did you use synthetic data?**  
Clinical data is sensitive. Synthetic data lets me demonstrate data structures and validation logic without exposing patient information or implying access to a real sponsor study. The limitations are stated in the README.

**What happens when a validation issue is found?**  
The pipeline logs the issue with a rule ID and record key. It does not silently edit the source record. In an actual study, the issue would be reviewed under the applicable SOP and resolved through the approved query/documentation process by authorized study personnel.

**How do you handle duplicate records?**  
I check the expected record grain—for example, one participant and scheduled visit, or one participant, visit and test. The issue log flags duplicates. For the demonstration summary, the first occurrence is retained as a documented analytical handling step; a real system would require source review and a controlled resolution.

**What is the difference between a data-quality issue and a protocol deviation?**  
A data-quality issue is a problem with the recorded data or its consistency. A protocol deviation is a departure from the approved protocol. They may overlap, but they are not interchangeable; each needs its own assessment and documentation.

**How did you calculate visit-window compliance?**  
For each deduplicated scheduled visit, I compare the absolute difference between actual and planned dates with the configured visit-window days. The rate uses all deduplicated scheduled visit records as the denominator. A missing or missed visit is not counted as within-window completion.

**How did you summarize adverse events?**  
I retained records with valid onset/end-date logic and summarized event counts, seriousness and affected participants by randomized group. This is descriptive only; it does not establish causality, exposure-adjusted risk or a safety signal.

**What does the hsCRP analysis show?**  
It compares paired Baseline and Week 12 hsCRP values by randomized group in the simulated dataset. The test and effect size are exploratory. They are not evidence of treatment efficacy, and the project does not include a full statistical analysis plan, multiplicity control, covariate adjustment or missing-data sensitivity analysis.

**What would you improve next?**  
I would add a formal metadata/data-dictionary layer, cross-domain referential-integrity checks, site-level metrics, configurable validation rules, a controlled terminology mapping exercise and CI/code-coverage reporting.

## Before sharing the repository

- Run `python -m triallens.pipeline --regenerate` and `pytest -q` successfully.
- Open the Streamlit dashboard and inspect the generated outputs.
- Be ready to explain at least the duplicate, date-chronology, visit-window, unit and AE date checks.
- Do not describe this as a real clinical trial, production CDM experience, validated EDC integration, or SDTM-compliant work.
