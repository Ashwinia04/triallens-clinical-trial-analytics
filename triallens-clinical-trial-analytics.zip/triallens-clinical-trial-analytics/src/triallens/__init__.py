"""TrialLens: simulated clinical-trial data quality and safety analytics."""
__version__ = "1.0.0"
