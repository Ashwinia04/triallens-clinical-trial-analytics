"""Generate a reproducible, fully synthetic Phase II clinical-trial dataset.

No real patient information or real investigational product is used.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

SEED = 20261125


def generate_dataset(output_dir: str | Path, n_participants: int = 120) -> dict[str, pd.DataFrame]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)

    participant_ids = [f"P{i:04d}" for i in range(1, n_participants + 1)]
    sites = ["SITE-01", "SITE-02", "SITE-03", "SITE-04"]
    arms = np.array(["TRX-101", "Placebo"] * (n_participants // 2) + (["TRX-101"] if n_participants % 2 else []))
    rng.shuffle(arms)
    consent_dates = pd.to_datetime("2025-01-06") + pd.to_timedelta(rng.integers(0, 100, n_participants), unit="D")
    randomization_dates = consent_dates + pd.to_timedelta(rng.integers(1, 8, n_participants), unit="D")

    participants = pd.DataFrame({
        "participant_id": participant_ids,
        "site_id": rng.choice(sites, n_participants),
        "country": rng.choice(["India", "United Kingdom", "Canada"], n_participants, p=[0.5, 0.25, 0.25]),
        "treatment_arm": arms,
        "age": rng.integers(21, 72, n_participants),
        "sex": rng.choice(["Female", "Male"], n_participants),
        "consent_date": consent_dates.strftime("%Y-%m-%d"),
        "randomization_date": randomization_dates.strftime("%Y-%m-%d"),
        "disposition": rng.choice(["Completed", "Discontinued"], n_participants, p=[0.88, 0.12]),
    })
    participants["discontinuation_reason"] = np.where(
        participants["disposition"].eq("Discontinued"),
        rng.choice(["Adverse event", "Withdrawal of consent", "Lost to follow-up"], n_participants),
        ""
    )

    visits_rows = []
    visit_schedule = [("Baseline", 0), ("Week 4", 28), ("Week 8", 56), ("Week 12", 84)]
    visit_num = 1
    for row in participants.itertuples(index=False):
        randomization = pd.Timestamp(row.randomization_date)
        discontinued = row.disposition == "Discontinued"
        discontinuation_day = int(rng.integers(25, 80)) if discontinued else 999
        for visit_name, day_offset in visit_schedule:
            planned = randomization + pd.Timedelta(days=day_offset)
            if discontinued and day_offset > discontinuation_day:
                status, actual = "Not Done", ""
            elif rng.random() < 0.075:
                status, actual = "Missed", ""
            else:
                status = "Completed"
                actual = (planned + pd.Timedelta(days=int(rng.integers(-5, 8)))).strftime("%Y-%m-%d")
            visits_rows.append({
                "visit_id": f"V{visit_num:05d}",
                "participant_id": row.participant_id,
                "visit_name": visit_name,
                "planned_date": planned.strftime("%Y-%m-%d"),
                "actual_date": actual,
                "visit_status": status,
                "window_days": 7,
            })
            visit_num += 1
    visits = pd.DataFrame(visits_rows)

    labs_rows = []
    lab_num = 1
    for row in participants.itertuples(index=False):
        baseline = float(rng.normal(8.5, 2.2))
        reduction = 1.9 if row.treatment_arm == "TRX-101" else 0.55
        week12 = max(0.4, baseline - reduction + float(rng.normal(0, 1.25)))
        alt_base = max(8.0, float(rng.normal(27, 8)))
        alt_week12 = max(8.0, alt_base + float(rng.normal(0, 4)))
        randomization = pd.Timestamp(row.randomization_date)
        for visit_name, day_offset, hscrp, alt in [
            ("Baseline", 0, baseline, alt_base),
            ("Week 12", 84, week12, alt_week12),
        ]:
            collection = randomization + pd.Timedelta(days=day_offset)
            for test_name, value, unit, low, high in [
                ("hsCRP", hscrp, "mg/L", 0.0, 5.0),
                ("ALT", alt, "U/L", 7.0, 56.0),
            ]:
                labs_rows.append({
                    "lab_id": f"L{lab_num:05d}",
                    "participant_id": row.participant_id,
                    "visit_name": visit_name,
                    "test_name": test_name,
                    "result_value": round(value, 2),
                    "unit": unit,
                    "reference_low": low,
                    "reference_high": high,
                    "collection_date": collection.strftime("%Y-%m-%d"),
                })
                lab_num += 1
    labs = pd.DataFrame(labs_rows)

    ae_terms = ["Headache", "Nausea", "Fatigue", "Injection-site reaction", "Upper respiratory tract infection", "Dizziness"]
    ae_rows = []
    ae_num = 1
    for row in participants.itertuples(index=False):
        n_ae = int(rng.poisson(0.72))
        for _ in range(n_ae):
            onset = pd.Timestamp(row.randomization_date) + pd.Timedelta(days=int(rng.integers(1, 85)))
            duration = int(rng.integers(1, 15))
            serious = bool(rng.random() < 0.055)
            ae_rows.append({
                "ae_id": f"AE{ae_num:05d}",
                "participant_id": row.participant_id,
                "ae_term": rng.choice(ae_terms),
                "onset_date": onset.strftime("%Y-%m-%d"),
                "end_date": (onset + pd.Timedelta(days=duration)).strftime("%Y-%m-%d"),
                "severity": rng.choice(["Mild", "Moderate", "Severe"], p=[0.56, 0.36, 0.08]),
                "seriousness": "Serious" if serious else "Non-serious",
                "relatedness": rng.choice(["Not related", "Unlikely", "Possible", "Probable"], p=[0.25, 0.2, 0.4, 0.15]),
                "outcome": rng.choice(["Recovered", "Recovering", "Not recovered"], p=[0.78, 0.15, 0.07]),
            })
            ae_num += 1
    adverse_events = pd.DataFrame(ae_rows, columns=["ae_id", "participant_id", "ae_term", "onset_date", "end_date", "severity", "seriousness", "relatedness", "outcome"])

    deviation_categories = ["Visit outside window", "Missed assessment", "Informed consent documentation", "Prohibited concomitant medication", "Eligibility documentation"]
    deviation_rows = []
    for idx in range(1, 31):
        p = rng.choice(participant_ids)
        deviation_rows.append({
            "deviation_id": f"PD{idx:04d}",
            "participant_id": p,
            "deviation_date": (pd.Timestamp("2025-02-01") + pd.Timedelta(days=int(rng.integers(0, 180)))).strftime("%Y-%m-%d"),
            "category": rng.choice(deviation_categories),
            "severity": rng.choice(["Minor", "Major"], p=[0.8, 0.2]),
            "reportable": rng.choice(["Yes", "No"], p=[0.25, 0.75]),
        })
    protocol_deviations = pd.DataFrame(deviation_rows)

    query_rows = []
    for idx in range(1, 66):
        opened = pd.Timestamp("2025-02-01") + pd.Timedelta(days=int(rng.integers(0, 190)))
        status = rng.choice(["Closed", "Open"], p=[0.72, 0.28])
        closed = (opened + pd.Timedelta(days=int(rng.integers(1, 18)))).strftime("%Y-%m-%d") if status == "Closed" else ""
        query_rows.append({
            "query_id": f"Q{idx:04d}",
            "participant_id": rng.choice(participant_ids),
            "domain": rng.choice(["DM", "VS", "LB", "AE", "EX"], p=[0.15, 0.2, 0.25, 0.3, 0.1]),
            "issue_type": rng.choice(["Missing value", "Out-of-range value", "Date inconsistency", "Clarification required", "Duplicate record"]),
            "status": status,
            "opened_date": opened.strftime("%Y-%m-%d"),
            "closed_date": closed,
        })
    queries = pd.DataFrame(query_rows)

    # Inject a small, documented set of data-entry issues so the QA rules can be demonstrated.
    participants.loc[participants["participant_id"].eq("P0002"), "age"] = 17
    participants.loc[participants["participant_id"].eq("P0003"), "age"] = 82
    participants.loc[participants["participant_id"].eq("P0004"), "randomization_date"] = (
        pd.Timestamp(participants.loc[participants["participant_id"].eq("P0004"), "consent_date"].iloc[0]) - pd.Timedelta(days=1)
    ).strftime("%Y-%m-%d")
    participants = pd.concat([participants, participants.loc[participants["participant_id"].eq("P0001")]], ignore_index=True)

    duplicate_visit = visits.loc[(visits["participant_id"] == "P0005") & (visits["visit_name"] == "Week 4")].copy()
    if not duplicate_visit.empty:
        duplicate_visit.loc[:, "visit_id"] = "V-DUP-0001"
        visits = pd.concat([visits, duplicate_visit], ignore_index=True)
    mask_missing_visit = (visits["participant_id"] == "P0006") & (visits["visit_name"] == "Week 8")
    visits.loc[mask_missing_visit, "visit_status"] = "Completed"
    visits.loc[mask_missing_visit, "actual_date"] = ""
    mask_late_visit = (visits["participant_id"] == "P0007") & (visits["visit_name"] == "Week 12")
    visits.loc[mask_late_visit, "visit_status"] = "Completed"
    visits.loc[mask_late_visit, "actual_date"] = (pd.Timestamp(visits.loc[mask_late_visit, "planned_date"].iloc[0]) + pd.Timedelta(days=25)).strftime("%Y-%m-%d")

    duplicate_lab = labs.loc[(labs["participant_id"] == "P0008") & (labs["visit_name"] == "Week 12") & (labs["test_name"] == "hsCRP")].copy()
    if not duplicate_lab.empty:
        duplicate_lab.loc[:, "lab_id"] = "L-DUP-0001"
        labs = pd.concat([labs, duplicate_lab], ignore_index=True)
    labs.loc[(labs["participant_id"] == "P0009") & (labs["visit_name"] == "Week 12") & (labs["test_name"] == "hsCRP"), "unit"] = "mg/dL"

    if not adverse_events.empty:
        ae_idx = adverse_events.index[0]
        onset = pd.Timestamp(adverse_events.loc[ae_idx, "onset_date"])
        adverse_events.loc[ae_idx, "end_date"] = (onset - pd.Timedelta(days=2)).strftime("%Y-%m-%d")
    closed_query_idx = queries.index[queries["status"].eq("Closed")]
    if len(closed_query_idx):
        queries.loc[closed_query_idx[0], "closed_date"] = ""

    frames = {
        "participants": participants,
        "visits": visits,
        "labs": labs,
        "adverse_events": adverse_events,
        "protocol_deviations": protocol_deviations,
        "queries": queries,
    }
    for name, frame in frames.items():
        frame.to_csv(output_dir / f"{name}.csv", index=False)
    return frames
