"""Analysis functions. All inferential summaries are exploratory and synthetic."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import stats


def _valid_participants(participants: pd.DataFrame) -> pd.DataFrame:
    p = participants.drop_duplicates("participant_id", keep="first").copy()
    p["age"] = pd.to_numeric(p["age"], errors="coerce")
    p["consent_date"] = pd.to_datetime(p["consent_date"], errors="coerce")
    p["randomization_date"] = pd.to_datetime(p["randomization_date"], errors="coerce")
    return p.loc[
        p["age"].between(18, 80)
        & p["consent_date"].notna()
        & p["randomization_date"].notna()
        & p["randomization_date"].ge(p["consent_date"])
    ].copy()


def analyze_trial(data: dict[str, pd.DataFrame]) -> dict:
    participants = _valid_participants(data["participants"])
    valid_ids = set(participants["participant_id"])

    visits = data["visits"].drop_duplicates(["participant_id", "visit_name"], keep="first").copy()
    visits = visits[visits["participant_id"].isin(valid_ids)].copy()
    visits["planned_date"] = pd.to_datetime(visits["planned_date"], errors="coerce")
    visits["actual_date"] = pd.to_datetime(visits["actual_date"], errors="coerce")
    visits["window_days"] = pd.to_numeric(visits["window_days"], errors="coerce").fillna(0)
    visits["within_window"] = (
        visits["visit_status"].eq("Completed")
        & visits["actual_date"].notna()
        & visits["planned_date"].notna()
        & ((visits["actual_date"] - visits["planned_date"]).dt.days.abs() <= visits["window_days"])
    )
    visit_summary = visits.groupby("visit_name", sort=False).agg(
        scheduled_records=("visit_id", "count"),
        completed_records=("visit_status", lambda x: int(x.eq("Completed").sum())),
        missed_records=("visit_status", lambda x: int(x.eq("Missed").sum())),
        within_window_records=("within_window", "sum"),
    ).reset_index()
    visit_summary["completion_rate_pct"] = (100 * visit_summary["completed_records"] / visit_summary["scheduled_records"]).round(1)
    visit_summary["within_window_rate_pct"] = (100 * visit_summary["within_window_records"] / visit_summary["scheduled_records"]).round(1)

    ae = data["adverse_events"].copy()
    ae = ae[ae["participant_id"].isin(valid_ids)].drop_duplicates("ae_id")
    ae["onset_date"] = pd.to_datetime(ae["onset_date"], errors="coerce")
    ae["end_date"] = pd.to_datetime(ae["end_date"], errors="coerce")
    ae = ae[ae["onset_date"].notna() & (ae["end_date"].isna() | ae["end_date"].ge(ae["onset_date"]))]
    ae = ae.merge(participants[["participant_id", "treatment_arm"]], on="participant_id", how="left")
    participants_with_ae = ae["participant_id"].nunique()
    ae_summary = ae.groupby(["treatment_arm", "seriousness"], dropna=False).size().rename("event_count").reset_index()
    ae_term_summary = ae.groupby("ae_term").size().rename("event_count").reset_index().sort_values("event_count", ascending=False)
    serious_events = int(ae["seriousness"].eq("Serious").sum())

    q = data["queries"].copy()
    q["opened_date"] = pd.to_datetime(q["opened_date"], errors="coerce")
    q["closed_date"] = pd.to_datetime(q["closed_date"], errors="coerce")
    closed = q["status"].eq("Closed") & q["closed_date"].notna()
    closure_rate = 100 * int(closed.sum()) / len(q) if len(q) else 0.0
    turnaround = (q.loc[closed, "closed_date"] - q.loc[closed, "opened_date"]).dt.days

    deviations = data["protocol_deviations"].copy()
    deviations = deviations[deviations["participant_id"].isin(valid_ids)]
    deviation_summary = deviations.groupby(["category", "severity"]).size().rename("deviation_count").reset_index()

    labs = data["labs"].copy()
    labs = labs[labs["participant_id"].isin(valid_ids)]
    labs = labs.drop_duplicates(["participant_id", "visit_name", "test_name"], keep="first")
    labs = labs[(labs["test_name"] == "hsCRP") & (labs["unit"] == "mg/L")].copy()
    labs["result_value"] = pd.to_numeric(labs["result_value"], errors="coerce")
    paired = labs[labs["visit_name"].isin(["Baseline", "Week 12"])].pivot_table(
        index="participant_id", columns="visit_name", values="result_value", aggfunc="first"
    ).dropna(subset=["Baseline", "Week 12"])
    paired = paired.join(participants.set_index("participant_id")["treatment_arm"], how="inner")
    paired["change_from_baseline"] = paired["Week 12"] - paired["Baseline"]
    biomarker_summary = paired.groupby("treatment_arm").agg(
        paired_participants=("change_from_baseline", "count"),
        mean_baseline=("Baseline", "mean"),
        mean_week12=("Week 12", "mean"),
        mean_change=("change_from_baseline", "mean"),
        sd_change=("change_from_baseline", "std"),
    ).reset_index()
    for col in ["mean_baseline", "mean_week12", "mean_change", "sd_change"]:
        biomarker_summary[col] = biomarker_summary[col].round(2)

    p_value = None
    effect_size = None
    treatment = paired.loc[paired["treatment_arm"].eq("TRX-101"), "change_from_baseline"].dropna().to_numpy()
    placebo = paired.loc[paired["treatment_arm"].eq("Placebo"), "change_from_baseline"].dropna().to_numpy()
    if len(treatment) > 1 and len(placebo) > 1:
        p_value = float(stats.ttest_ind(treatment, placebo, equal_var=False).pvalue)
        pooled_sd = np.sqrt(((len(treatment) - 1) * np.var(treatment, ddof=1) + (len(placebo) - 1) * np.var(placebo, ddof=1)) / (len(treatment) + len(placebo) - 2))
        effect_size = float((np.mean(treatment) - np.mean(placebo)) / pooled_sd) if pooled_sd else None

    metrics = {
        "participants_in_raw_export": int(data["participants"]["participant_id"].nunique()),
        "participants_in_analysis": int(len(participants)),
        "participant_records_in_raw_export": int(len(data["participants"])),
        "adverse_events_in_analysis": int(len(ae)),
        "participants_with_at_least_one_ae": int(participants_with_ae),
        "participants_with_ae_pct": round(100 * participants_with_ae / len(participants), 1) if len(participants) else 0,
        "serious_ae_count": serious_events,
        "query_records": int(len(q)),
        "queries_closed_with_valid_close_date": int(closed.sum()),
        "query_closure_rate_pct": round(closure_rate, 1),
        "median_query_turnaround_days": round(float(turnaround.median()), 1) if len(turnaround) else None,
        "protocol_deviation_records": int(len(deviations)),
        "paired_hscrp_participants": int(len(paired)),
        "exploratory_welch_p_value": f"{p_value:.3g}" if p_value is not None else None,
        "exploratory_cohens_d": round(effect_size, 3) if effect_size is not None else None,
    }
    return {
        "metrics": metrics,
        "visit_summary": visit_summary,
        "ae_summary": ae_summary,
        "ae_term_summary": ae_term_summary,
        "deviation_summary": deviation_summary,
        "biomarker_summary": biomarker_summary,
        "paired_biomarker_data": paired.reset_index(),
    }
