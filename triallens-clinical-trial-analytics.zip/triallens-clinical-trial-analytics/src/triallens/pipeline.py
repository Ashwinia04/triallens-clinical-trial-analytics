"""Run the full TrialLens pipeline from raw CSV exports to analysis outputs."""
from __future__ import annotations
import argparse
import json
import sqlite3
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
from .generate_data import generate_dataset
from .quality import run_quality_checks
from .analysis import analyze_trial


def load_raw_data(data_dir: Path) -> dict[str, pd.DataFrame]:
    names = ["participants", "visits", "labs", "adverse_events", "protocol_deviations", "queries"]
    return {name: pd.read_csv(data_dir / f"{name}.csv", keep_default_na=False) for name in names}


def _write_database(data: dict[str, pd.DataFrame], outputs: Path, issues: pd.DataFrame) -> None:
    db_path = outputs / "triallens.db"
    if db_path.exists():
        db_path.unlink()
    with sqlite3.connect(db_path) as conn:
        for name, frame in data.items():
            frame.to_sql(name, conn, index=False, if_exists="replace")
        issues.to_sql("quality_issues", conn, index=False, if_exists="replace")


def _write_plots(issues: pd.DataFrame, analysis: dict, plots_dir: Path) -> None:
    plots_dir.mkdir(parents=True, exist_ok=True)
    if not issues.empty:
        counts = issues.groupby("severity").size().reindex(["Critical", "High", "Medium", "Low"], fill_value=0)
        fig, ax = plt.subplots(figsize=(7, 4))
        counts.plot(kind="bar", ax=ax)
        ax.set_title("Data-quality findings by severity")
        ax.set_xlabel("Severity")
        ax.set_ylabel("Number of findings")
        fig.tight_layout()
        fig.savefig(plots_dir / "quality_findings_by_severity.png", dpi=160)
        plt.close(fig)

    visit = analysis["visit_summary"]
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(visit["visit_name"], visit["within_window_rate_pct"])
    ax.set_title("Visits completed within the protocol window")
    ax.set_xlabel("Scheduled visit")
    ax.set_ylabel("Within-window rate (%)")
    ax.set_ylim(0, 105)
    fig.tight_layout()
    fig.savefig(plots_dir / "visit_window_compliance.png", dpi=160)
    plt.close(fig)

    paired = analysis["paired_biomarker_data"]
    fig, ax = plt.subplots(figsize=(7, 4))
    if not paired.empty:
        paired.boxplot(column="change_from_baseline", by="treatment_arm", ax=ax)
    ax.set_title("Exploratory hsCRP change from baseline to Week 12")
    fig.suptitle("")
    ax.set_xlabel("Randomized group")
    ax.set_ylabel("Change in hsCRP (mg/L)")
    fig.tight_layout()
    fig.savefig(plots_dir / "hscrp_change_by_arm.png", dpi=160)
    plt.close(fig)


def _write_report(outputs: Path, issues: pd.DataFrame, result: dict) -> None:
    m = result["metrics"]
    severity = issues["severity"].value_counts().to_dict() if not issues.empty else {}
    biomarker = result["biomarker_summary"].to_string(index=False) if not result["biomarker_summary"].empty else "No paired biomarker records available."
    report = f'''# TrialLens — Automated analysis summary

> **Dataset:** fully synthetic, simulated Phase II study; no real patient data.

## Cohort and data quality

- Unique participant IDs in source export: **{m['participants_in_raw_export']}**
- Participants retained for analysis after predefined eligibility and chronology checks: **{m['participants_in_analysis']}**
- Participant rows in source export: **{m['participant_records_in_raw_export']}**
- Total QA findings: **{len(issues)}**
- Findings by severity: `{severity}`

## Operational and safety indicators

- Visits are summarized in `visit_summary.csv`; the within-window rate uses all deduplicated scheduled records as the denominator.
- Adverse events retained after date-integrity checks: **{m['adverse_events_in_analysis']}**
- Participants with at least one retained AE: **{m['participants_with_at_least_one_ae']} ({m['participants_with_ae_pct']}%)**
- Serious AE records retained: **{m['serious_ae_count']}**
- Query closure rate with a valid close date: **{m['query_closure_rate_pct']}%**
- Median query turnaround among validly closed queries: **{m['median_query_turnaround_days']} days**
- Protocol deviation records in the analysis cohort: **{m['protocol_deviation_records']}**

## Exploratory biomarker summary

Paired hsCRP results (Baseline and Week 12; mg/L) are summarized by randomized group:

```text
{biomarker}
```

Welch test p-value: **{m['exploratory_welch_p_value']}**; Cohen's d: **{m['exploratory_cohens_d']}**.

These are **illustrative descriptive/exploratory statistics on synthetic data only**. They are not evidence of efficacy, safety, or a treatment recommendation. No multiplicity adjustment, covariate adjustment, missing-data sensitivity analysis, or clinical adjudication is performed.

## Interpretation guardrails

1. A data-quality finding is not automatically a protocol deviation or a safety signal.
2. A clinically out-of-reference-range laboratory value is not treated as a data-entry error by itself.
3. The pipeline flags records; it does not silently overwrite or clinically adjudicate source data.
4. Analysis exclusions are limited to explicit, documented integrity/eligibility rules in the code.
'''
    (outputs.parent / "reports" / "analysis_summary.md").write_text(report, encoding="utf-8")


def run_pipeline(root: Path, regenerate: bool = False) -> dict:
    data_dir = root / "data" / "raw"
    outputs = root / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)
    if regenerate or not all((data_dir / f"{n}.csv").exists() for n in ["participants", "visits", "labs", "adverse_events", "protocol_deviations", "queries"]):
        generate_dataset(data_dir)
    data = load_raw_data(data_dir)
    issues = run_quality_checks(data)
    result = analyze_trial(data)
    issues.to_csv(outputs / "quality_issues.csv", index=False)
    for key in ["visit_summary", "ae_summary", "ae_term_summary", "deviation_summary", "biomarker_summary", "paired_biomarker_data"]:
        result[key].to_csv(outputs / f"{key}.csv", index=False)
    (outputs / "metrics.json").write_text(json.dumps(result["metrics"], indent=2), encoding="utf-8")
    _write_database(data, outputs, issues)
    _write_plots(issues, result, outputs / "plots")
    _write_report(outputs, issues, result)
    return {"issues": issues, "analysis": result}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the TrialLens simulated clinical-trial analytics pipeline.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2], help="Project root directory")
    parser.add_argument("--regenerate", action="store_true", help="Regenerate the deterministic synthetic source data")
    args = parser.parse_args()
    result = run_pipeline(args.root, regenerate=args.regenerate)
    print(f"Pipeline complete. QA findings: {len(result['issues'])}")
    print(f"Analysis metrics: {args.root / 'outputs' / 'metrics.json'}")

if __name__ == "__main__":
    main()
