# TrialLens — Automated analysis summary

> **Dataset:** fully synthetic, simulated Phase II study; no real patient data.

## Cohort and data quality

- Unique participant IDs in source export: **120**
- Participants retained for analysis after predefined eligibility and chronology checks: **117**
- Participant rows in source export: **121**
- Total QA findings: **11**
- Findings by severity: `{'High': 7, 'Critical': 2, 'Medium': 2}`

## Operational and safety indicators

- Visits are summarized in `visit_summary.csv`; the within-window rate uses all deduplicated scheduled records as the denominator.
- Adverse events retained after date-integrity checks: **81**
- Participants with at least one retained AE: **59 (50.4%)**
- Serious AE records retained: **6**
- Query closure rate with a valid close date: **72.3%**
- Median query turnaround among validly closed queries: **7.0 days**
- Protocol deviation records in the analysis cohort: **30**

## Exploratory biomarker summary

Paired hsCRP results (Baseline and Week 12; mg/L) are summarized by randomized group:

```text
treatment_arm  paired_participants  mean_baseline  mean_week12  mean_change  sd_change
      Placebo                   60           8.59         8.05        -0.54       1.29
      TRX-101                   56           8.34         6.34        -1.99       1.21
```

Welch test p-value: **6.71e-09**; Cohen's d: **-1.162**.

These are **illustrative descriptive/exploratory statistics on synthetic data only**. They are not evidence of efficacy, safety, or a treatment recommendation. No multiplicity adjustment, covariate adjustment, missing-data sensitivity analysis, or clinical adjudication is performed.

## Interpretation guardrails

1. A data-quality finding is not automatically a protocol deviation or a safety signal.
2. A clinically out-of-reference-range laboratory value is not treated as a data-entry error by itself.
3. The pipeline flags records; it does not silently overwrite or clinically adjudicate source data.
4. Analysis exclusions are limited to explicit, documented integrity/eligibility rules in the code.
