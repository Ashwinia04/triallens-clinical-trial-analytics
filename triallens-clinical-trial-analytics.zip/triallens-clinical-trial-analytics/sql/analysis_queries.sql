-- Run against outputs/triallens.db using SQLite.

-- 1. Source export size and unique participant count.
SELECT COUNT(*) AS participant_rows,
       COUNT(DISTINCT participant_id) AS unique_participants
FROM participants;

-- 2. Quality findings by rule and severity.
SELECT rule_id, domain, severity, COUNT(*) AS finding_count
FROM quality_issues
GROUP BY rule_id, domain, severity
ORDER BY CASE severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END,
         finding_count DESC;

-- 3. Visit status distribution.
SELECT visit_name, visit_status, COUNT(*) AS records
FROM visits
GROUP BY visit_name, visit_status
ORDER BY visit_name, visit_status;

-- 4. Adverse-event counts by randomized group and seriousness.
SELECT p.treatment_arm, ae.seriousness, COUNT(*) AS event_count,
       COUNT(DISTINCT ae.participant_id) AS participants_affected
FROM adverse_events ae
JOIN participants p ON p.participant_id = ae.participant_id
GROUP BY p.treatment_arm, ae.seriousness
ORDER BY p.treatment_arm, ae.seriousness;

-- 5. Query workload and closure status.
SELECT status, COUNT(*) AS query_count
FROM queries
GROUP BY status;

-- 6. Laboratory records by test and unit (useful for unit harmonisation review).
SELECT test_name, unit, COUNT(*) AS record_count
FROM labs
GROUP BY test_name, unit
ORDER BY test_name, unit;
